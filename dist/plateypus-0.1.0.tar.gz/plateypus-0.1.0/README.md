# PLATEypus 
A simple GUI to process and plot bulk cytokine, surface marker, and single cell data exported from flowjo

To use this package:
1. Download and unzip package into an easily accessible (not Downloads) folder in your computer 
2. Navigate to that folder in terminal, then run ./PLATEypus.py 
3. Follow instructions in powerpoint tutorial 
