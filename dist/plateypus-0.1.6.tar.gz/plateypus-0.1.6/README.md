![PLATEypusLogo](https://user-images.githubusercontent.com/49458891/116960335-185c1500-ac6e-11eb-92e0-369334eb7882.png)

A GUI to process and plot high throughput bulk cytokine, surface marker, and single cell data exported from flowjo

To use this package:
1. Install via PyPi: pip install plateypus
2. In an anaconda environment, type python3 plateypus to start the GUI
