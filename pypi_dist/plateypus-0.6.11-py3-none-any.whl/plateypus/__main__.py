#!/usr/bin/env python3

import os
import pickle
import shutil
import tkinter as tk
import tkinter.ttk

import pandas as pd
from PIL import Image, ImageTk
from importlib_metadata import version

from plateypus.app_paths import (
    ensure_user_data_files_exist,
    get_misc_directory,
    get_resource_directory,
    get_user_data_directory,
)
from plateypus.dataprocessing.dataProcessingGUI import DataProcessingStartPage
from plateypus.dataprocessing.miscFunctions import setMaxWidth
from plateypus.plotting.plottingGUI import PlotExperimentWindow
from plateypus.setup.experimentCreationGUI import (
    NewExperimentWindow,
    NewProjectWindow,
    RemoveProjectWindow,
)
from plateypus.setup.experimentSetupGUI import ExperimentSetupStartPage


if os.name == "nt":
    dirSep = "\\"
else:
    dirSep = "/"

def path_with_trailing_separator(path_object):
    path_string = str(path_object)

    if not path_string.endswith(dirSep):
        path_string += dirSep

    return path_string


class MainApp(tk.Tk):
    def __init__(self):
        self.root = tk.Tk.__init__(self)
        self.title("plateypus " + version("plateypus"))
        self._frame = None

        ensure_user_data_files_exist()

        self.resourceDirectory = path_with_trailing_separator(get_resource_directory())
        self.homedirectory = path_with_trailing_separator(get_user_data_directory())
        self.miscDirectory = path_with_trailing_separator(get_misc_directory())

        icon_path = os.path.join(self.resourceDirectory, "plateypus.ico")

        try:
            self.iconbitmap(default=icon_path)
        except Exception as error:
            print("Could not set plateypus window icon:", error)

        print("plateypus resource location: " + self.resourceDirectory)
        print("plateypus user data location: " + self.homedirectory)
        print("plateypus misc location: " + self.miscDirectory)

        self.switch_frame(ExperimentSelectionPage)

    def quit_app(self) -> None:
        self.quit()
        self.destroy()

    def switch_frame(self, frame_class, *args):
        """
        Destroy the current frame and replace it with a new one.
        """
        new_frame = frame_class(self, *args)

        if self._frame is not None:
            self._frame.destroy()

        self._frame = new_frame
        self._frame.pack()


class ExperimentSelectionPage(tk.Frame):
    def __init__(self, master):
        tk.Frame.__init__(self, master)

        mainWindow = tk.Frame(self)
        mainWindow.pack(side=tk.TOP, padx=10)

        logo_path = master.resourceDirectory + "plateypusLogo.png"
        load = Image.open(logo_path)

        width, height = load.size
        SCALEFACTOR = 0.4

        load = load.resize(
            (int(SCALEFACTOR * width), int(SCALEFACTOR * height)),
            Image.ANTIALIAS,
        )

        render = ImageTk.PhotoImage(load)
        img = tk.Label(mainWindow, image=render)
        img.image = render
        img.grid(row=0, column=0, columnspan=3)

        v = tk.StringVar(value="slt")

        rb1c = tk.Button(
            mainWindow,
            text="Associate new experiment with project",
            padx=20,
            command=lambda: master.switch_frame(
                NewExperimentWindow,
                ExperimentSelectionPage,
            ),
        )
        rb1c.grid(row=3, column=0, sticky=tk.EW, columnspan=3, pady=1)

        rb1a = tk.Button(
            mainWindow,
            text="Create new project",
            padx=20,
            command=lambda: master.switch_frame(
                NewProjectWindow,
                ExperimentSelectionPage,
            ),
        )

        rb1b = tk.Button(
            mainWindow,
            text="Remove project",
            padx=20,
            command=lambda: master.switch_frame(
                RemoveProjectWindow,
                ExperimentSelectionPage,
            ),
        )

        rb1a.grid(row=1, column=0, sticky=tk.EW, columnspan=3, pady=(20, 1))
        rb1b.grid(row=2, column=0, sticky=tk.EW, columnspan=3, pady=1)

        expSelectionFrame = tk.Frame(mainWindow, borderwidth=1, relief=tk.SOLID)
        expSelectionFrame.grid(
            row=4,
            column=0,
            sticky=tk.EW,
            columnspan=3,
            pady=(10, 0),
        )

        rb1d = tk.Button(
            expSelectionFrame,
            text="Work on existing experiment ",
            padx=20,
            command=lambda: collectInput(),
        )

        def getUpdateData(event):
            projectName = self.projectMenu.get()
            pathName = self.pathDict[projectName]

            experiments = []

            for experimentName in os.listdir(pathName + projectName):
                if ".DS" not in experimentName:
                    experiments.append(experimentName)

            experiments = sorted(experiments)[::-1]

            self.experimentMenu["values"] = experiments

            if len(experiments) == 1:
                self.experimentMenu.set(self.experimentMenu["values"][0])

            self.experimentMenu["width"] = len(max(experiments, key=len))

        if "misc" not in os.listdir(master.homedirectory):
            os.mkdir(master.homedirectory + "misc")

        if "pathDict.pkl" not in os.listdir(master.homedirectory + "misc"):
            self.pathDict = {}
        else:
            self.pathDict = pickle.load(
                open(master.homedirectory + "misc" + dirSep + "pathDict.pkl", "rb")
            )

        if "cytokineMWDf.csv" not in os.listdir(master.homedirectory + "misc"):
            shutil.copy(
                master.resourceDirectory
                + "templates"
                + dirSep
                + "cytokineMWDf_template.csv",
                master.homedirectory + "misc" + dirSep + "cytokineMWDf.csv",
            )

        if "kitDf.csv" not in os.listdir(master.homedirectory + "misc"):
            shutil.copy(
                master.resourceDirectory + "templates" + dirSep + "kitDf_template.csv",
                master.homedirectory + "misc" + dirSep + "kitDf.csv",
            )

        projects = list(self.pathDict.keys())

        self.projectMenu = tkinter.ttk.Combobox(expSelectionFrame, values=projects)

        if len(self.pathDict) > 0:
            self.projectMenu["width"] = len(max(projects, key=len))

        tk.Label(expSelectionFrame, text="Project name: ").pack()

        self.projectMenu.pack()
        self.projectMenu.bind("<<ComboboxSelected>>", getUpdateData)

        self.experimentMenu = tkinter.ttk.Combobox(expSelectionFrame)

        tk.Label(expSelectionFrame, text="Experiment name: ").pack()

        self.experimentMenu.pack()
        rb1d.pack(expand=True, fill=tk.BOTH, pady=(5, 0))

        def collectInput():
            projectName = self.projectMenu.get()
            pathName = self.pathDict[projectName]
            selectedExperiment = self.experimentMenu.get()

            os.chdir(pathName + projectName + dirSep + selectedExperiment)

            master.switch_frame(ExperimentActionWindow, selectedExperiment)

        buttonWindow = tk.Frame(self)
        buttonWindow.pack(side=tk.TOP, padx=10, pady=(50, 10))

        tk.Button(buttonWindow, text="Quit", command=master.quit_app).pack(side=tk.LEFT)


class ExperimentActionWindow(tk.Frame):
    def __init__(self, master, selectedExperiment):
        tk.Frame.__init__(self, master)

        mainWindow = tk.Frame(self)
        mainWindow.pack(side=tk.TOP, padx=10)

        l1 = tk.Label(mainWindow, text="Choose an action:")

        v = tk.StringVar(value="plt")

        rb1a = tk.Radiobutton(
            mainWindow,
            text="Setup experiment",
            padx=20,
            variable=v,
            value="se",
        )

        rb1b = tk.Radiobutton(
            mainWindow,
            text="Process experiment",
            padx=20,
            variable=v,
            value="pd",
        )

        rb1c = tk.Radiobutton(
            mainWindow,
            text="Plot experiment",
            padx=20,
            variable=v,
            value="plt",
        )

        l1.grid(row=0, column=0)
        rb1a.grid(row=1, column=0, sticky=tk.W)
        rb1b.grid(row=2, column=0, sticky=tk.W)
        rb1c.grid(row=3, column=0, sticky=tk.W)

        def collectInput():
            action = v.get()

            if action == "se":
                master.switch_frame(
                    ExperimentSetupStartPage,
                    selectedExperiment,
                    ExperimentActionWindow,
                )
            elif action == "pd":
                master.switch_frame(
                    DataProcessingStartPage,
                    selectedExperiment,
                    32,
                    [],
                    ExperimentActionWindow,
                )
            elif action == "plt":
                master.switch_frame(
                    PlotExperimentWindow,
                    selectedExperiment,
                    ExperimentActionWindow,
                )

        def backCommand():
            os.chdir(master.homedirectory)
            master.switch_frame(ExperimentSelectionPage)

        buttonWindow = tk.Frame(self)
        buttonWindow.pack(side=tk.TOP, padx=10, pady=10)

        tk.Button(buttonWindow, text="OK", command=lambda: collectInput()).pack(
            side=tk.LEFT
        )

        tk.Button(buttonWindow, text="Back", command=lambda: backCommand()).pack(
            side=tk.LEFT
        )

        tk.Button(buttonWindow, text="Quit", command=master.quit_app).pack(side=tk.LEFT)


def main() -> None:
    app = MainApp()
    app.mainloop()


if __name__ == "__main__":
    main()
